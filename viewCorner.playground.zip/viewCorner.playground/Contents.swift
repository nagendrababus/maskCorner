import UIKit
import PlaygroundSupport

class MyViewController : UIViewController{
    
    var cardView: UIView!
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = UIColor.black
        
        cardView = UIView()
        view.addSubview(cardView)
        
        cardView.translatesAutoresizingMaskIntoConstraints = false
        cardView.widthAnchor.constraint(equalToConstant: 200).isActive = true
        cardView.heightAnchor.constraint(equalToConstant: 200).isActive = true
        cardView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        cardView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
        
        cardView.backgroundColor = UIColor(red: 1.0, green: 0.784, blue: 0.2, alpha: 1.0)
        
        self.view = view
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cardView.roundedCorners(cornerRadius: 20.0)
        
        let tapRecog = UITapGestureRecognizer(target: self, action: #selector(animateCornerChange))
        cardView.addGestureRecognizer(tapRecog)
    }
    
    @objc func animateCornerChange(){
        
        let targetRadius:CGFloat = (cardView.layer.cornerRadius == 0.0) ? 100.0 : 0.0
        UIViewPropertyAnimator(duration: 1.0, curve: .easeInOut) {
            self.cardView.layer.cornerRadius = targetRadius
        }.startAnimation()
    }
    
}

extension UIView{
    
    func roundedCorners(cornerRadius:Double){
        self.layer.cornerRadius = CGFloat(cornerRadius)
        self.clipsToBounds = true
        self.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
    }
}

PlaygroundPage.current.liveView = MyViewController()
